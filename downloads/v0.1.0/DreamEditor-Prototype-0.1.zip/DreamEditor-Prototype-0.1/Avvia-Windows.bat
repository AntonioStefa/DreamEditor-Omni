@echo off
cd /d "%~dp0"
node start.mjs --open
pause
