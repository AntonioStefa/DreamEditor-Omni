#!/bin/sh
cd "$(dirname "$0")"
node start.mjs --open
